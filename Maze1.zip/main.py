from maze import *
maze = Maze("input4.txt")
maze.analyze()
maze.display()